from django.contrib import admin

from fit.models import Post, Perfil

# Register your models here.

admin.site.register(Post)
admin.site.register(Perfil)